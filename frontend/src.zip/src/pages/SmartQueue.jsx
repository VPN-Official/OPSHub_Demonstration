import React, { useState, useEffect } from "react";
import { useNotifications } from "../context/NotificationsContext";
import SmartQueueFilters from "../components/smartqueue/SmartQueueFilters";
import SmartQueueTable from "../components/smartqueue/SmartQueueTable";
import SmartQueueCard from "../components/smartqueue/SmartQueueCard";
import SmartQueuePagination from "../components/smartqueue/SmartQueuePagination";

export default function SmartQueue() {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [filter, setFilter] = useState("all");
  const [sortBy, setSortBy] = useState("smartScore");
  const [page, setPage] = useState(1);
  const [showReasonId, setShowReasonId] = useState(null);

  const { addNotification } = useNotifications();

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Mock WorkItems (replace with API later)
  const workItems = [
    { id: 101, title: "DB latency issue", severity: "critical", assigned: false, smartScore: 95, reason: "Query spikes at peak hour" },
    { id: 102, title: "Node CPU > 95%", severity: "warning", assigned: true, smartScore: 78, reason: "Background jobs eating CPU" },
    { id: 103, title: "Disk cleanup required", severity: "info", assigned: false, smartScore: 60, reason: "Temp files not purged" },
  ];

  // Filtering
  const filtered = workItems.filter((wi) => {
    if (filter === "all") return true;
    if (filter === "assigned" && wi.assigned) return true;
    if (filter === "unassigned" && !wi.assigned) return true;
    return false;
  });

  // Sorting
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === "smartScore") return b.smartScore - a.smartScore;
    if (sortBy === "severity") {
      const order = { critical: 1, warning: 2, info: 3 };
      return (order[a.severity] || 99) - (order[b.severity] || 99);
    }
    return 0;
  });

  // Pagination
  const pageSize = 5;
  const paginated = sorted.slice((page - 1) * pageSize, page * pageSize);

  const handleAddNotification = (msg) => {
    addNotification({
      id: Date.now(),
      severity: "info",
      msg,
      ts: new Date().toLocaleTimeString(),
    });
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Smart Queue</h1>
      <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
        Curated work items requiring attention. Events are deduplicated,
        enriched, and prioritized here for action.
      </p>

      <SmartQueueFilters
        filter={filter}
        setFilter={setFilter}
        sortBy={sortBy}
        setSortBy={setSortBy}
      />

      {!isMobile ? (
        <SmartQueueTable
          workItems={paginated}
          showReasonId={showReasonId}
          setShowReasonId={setShowReasonId}
          handleAddNotification={handleAddNotification}
        />
      ) : (
        <SmartQueueCard
          workItems={paginated}
          showReasonId={showReasonId}
          setShowReasonId={setShowReasonId}
          handleAddNotification={handleAddNotification}
        />
      )}

      <SmartQueuePagination
        page={page}
        setPage={setPage}
        total={sorted.length}
        pageSize={pageSize}
      />

      {paginated.length === 0 && (
        <p className="text-gray-500 text-sm mt-4">No work items</p>
      )}
    </div>
  );
}
