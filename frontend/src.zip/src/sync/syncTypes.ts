// src/sync/syncTypes.ts

export type SyncAction = "create" | "update" | "delete";

export type SyncStatus =
  | "pending"       // waiting in queue
  | "in_progress"   // actively syncing
  | "success"       // synced successfully
  | "failed"        // permanently failed (after retries)
  | "conflict";     // conflict detected

export interface SyncMetadata {
  attemptCount: number;     // number of retries
  lastAttemptAt?: string;   // ISO timestamp
  errorMessage?: string;    // last error encountered
  conflictDetails?: any;    // extra info if conflict
}

export interface SyncItem<T = any> {
  id: string;               // unique id for queue item
  tenantId: string;         // tenant scope
  entityType: string;       // "incident", "service_request", etc.
  entityId: string;         // actual business entity id
  action: SyncAction;       // what operation to perform
  payload: T;               // full object (for create/update) or stub (for delete)
  status: SyncStatus;       // current sync state
  enqueuedAt: string;       // ISO timestamp
  metadata: SyncMetadata;   // retry + error details
}