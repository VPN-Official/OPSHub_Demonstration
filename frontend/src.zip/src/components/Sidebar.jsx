import React from "react";
import { NavLink } from "react-router-dom";
import {
  Activity,
  ListChecks,
  Bell,
  Calendar,
  Zap,
} from "lucide-react";

export default function Sidebar({ isOpen, onClose }) {
  const menuItems = [
    { to: "/pulse", label: "Pulse", icon: Activity },
    { to: "/smartqueue", label: "Smart Queue", icon: ListChecks },
    { to: "/notifications", label: "Notifications", icon: Bell },
    { to: "/schedule", label: "Schedule", icon: Calendar },
    { to: "/intelligence", label: "Intelligence Center", icon: Zap },
  ];

  return (
    <div
      className={`fixed inset-y-0 left-0 z-30 w-64 bg-[var(--sidebar-bg)] text-[var(--fg)] shadow-lg transform transition-transform duration-200 ease-in-out
        ${isOpen ? "translate-x-0" : "-translate-x-full"} md:translate-x-0`}
    >
      <div className="flex flex-col h-full">
        {/* Logo / App Name */}
        <div className="p-4 font-bold text-lg border-b border-[var(--border)]">
          OPSHub
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-2 space-y-1">
          {menuItems.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-2 px-3 py-2 rounded hover:bg-[var(--hover-bg)] transition ${
                  isActive
                    ? "bg-blue-600 text-white font-semibold"
                    : "text-[var(--fg)]"
                }`
              }
              onClick={onClose}
            >
              <Icon size={18} /> {label}
            </NavLink>
          ))}
        </nav>
      </div>
    </div>
  );
}