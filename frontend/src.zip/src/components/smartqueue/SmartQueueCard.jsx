import React from "react";
import { useNavigate } from "react-router-dom";

export default function SmartQueueCard({ workItems, showReasonId, setShowReasonId, handleAddNotification }) {
  const navigate = useNavigate();

  return (
    <div className="space-y-3">
      {workItems.map((wi) => (
        <div key={wi.id} className="p-3 bg-white dark:bg-gray-900 rounded shadow">
          <div className="flex justify-between">
            <span
              className="font-semibold text-blue-600 cursor-pointer"
              onClick={() => navigate(`/workitem/${wi.id}`)}
            >
              {wi.title}
            </span>
            <span
              className={`px-2 py-0.5 text-xs text-white rounded ${
                wi.severity === "critical"
                  ? "bg-red-600"
                  : wi.severity === "warning"
                  ? "bg-orange-500"
                  : "bg-blue-500"
              }`}
            >
              {wi.severity.toUpperCase()}
            </span>
          </div>
          <p className="text-xs text-gray-500">Smart Score: {wi.smartScore}</p>
          <div className="flex gap-2 mt-2">
            <button
              onClick={() => handleAddNotification(`WorkItem ${wi.id} assigned to you`)}
              className="px-2 py-1 text-xs bg-blue-600 text-white rounded"
            >
              Assign
            </button>
            <button
              onClick={() => handleAddNotification(`Automation triggered on WorkItem ${wi.id}`)}
              className="px-2 py-1 text-xs bg-green-600 text-white rounded"
            >
              Automation
            </button>
            <button
              onClick={() => handleAddNotification(`Chat started on WorkItem ${wi.id}`)}
              className="px-2 py-1 text-xs bg-gray-600 text-white rounded"
            >
              Chat
            </button>
            <button
              onClick={() => setShowReasonId(showReasonId === wi.id ? null : wi.id)}
              className="px-2 py-1 text-xs bg-orange-600 text-white rounded"
            >
              Why?
            </button>
          </div>
          {showReasonId === wi.id && (
            <div className="mt-2 text-xs text-gray-700 dark:text-gray-300">{wi.reason}</div>
          )}
        </div>
      ))}
    </div>
  );
}
