import React from "react";
import { useNavigate } from "react-router-dom";

export default function SmartQueueTable({ workItems, showReasonId, setShowReasonId, handleAddNotification }) {
  const navigate = useNavigate();

  return (
    <table className="w-full text-sm border">
      <thead className="bg-gray-100 dark:bg-gray-800">
        <tr>
          <th className="px-3 py-2">ID</th>
          <th className="px-3 py-2">Title</th>
          <th className="px-3 py-2">Severity</th>
          <th className="px-3 py-2">Smart Score</th>
          <th className="px-3 py-2">Actions</th>
        </tr>
      </thead>
      <tbody>
        {workItems.map((wi) => (
          <tr key={wi.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
            <td className="px-3 py-2">{wi.id}</td>
            <td
              className="px-3 py-2 text-blue-600 cursor-pointer"
              onClick={() => navigate(`/workitem/${wi.id}`)}
            >
              {wi.title}
            </td>
            <td className="px-3 py-2">{wi.severity}</td>
            <td className="px-3 py-2">{wi.smartScore}</td>
            <td className="px-3 py-2 flex gap-2">
              <button
                onClick={() => handleAddNotification(`WorkItem ${wi.id} assigned to you`)}
                className="px-2 py-1 text-xs bg-blue-600 text-white rounded"
              >
                Assign
              </button>
              <button
                onClick={() => handleAddNotification(`Automation triggered on WorkItem ${wi.id}`)}
                className="px-2 py-1 text-xs bg-green-600 text-white rounded"
              >
                Automation
              </button>
              <button
                onClick={() => handleAddNotification(`Chat started on WorkItem ${wi.id}`)}
                className="px-2 py-1 text-xs bg-gray-600 text-white rounded"
              >
                Chat
              </button>
              <button
                onClick={() => setShowReasonId(showReasonId === wi.id ? null : wi.id)}
                className="px-2 py-1 text-xs bg-orange-600 text-white rounded"
              >
                Why?
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
