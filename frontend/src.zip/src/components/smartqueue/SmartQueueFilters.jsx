import React from "react";

export default function SmartQueueFilters({ filter, setFilter, sortBy, setSortBy }) {
  return (
    <div className="flex gap-2 mb-4">
      {["all", "assigned", "unassigned"].map((f) => (
        <button
          key={f}
          onClick={() => setFilter(f)}
          className={`px-3 py-1 rounded text-sm ${
            filter === f
              ? "bg-blue-600 text-white"
              : "bg-gray-200 dark:bg-gray-700"
          }`}
        >
          {f.charAt(0).toUpperCase() + f.slice(1)}
        </button>
      ))}
      <select
        value={sortBy}
        onChange={(e) => setSortBy(e.target.value)}
        className="ml-auto px-2 py-1 rounded bg-gray-200 dark:bg-gray-700 text-sm"
      >
        <option value="smartScore">Smart Score</option>
        <option value="severity">Severity</option>
      </select>
    </div>
  );
}
