import React, { useEffect, useState } from "react";
import { useWorkItems } from "../contexts/WorkItemsContext.jsx";
import { useCosts } from "../contexts/CostsContext.jsx";
import { useAutomations } from "../contexts/AutomationsContext.jsx";
import { useAuth } from "../contexts/AuthContext.jsx";
import { Activity, AlertTriangle, TrendingDown, Clock } from "lucide-react"; 
import { Link } from "react-router-dom";

export default function Pulse({ role }) {
  const { workItems = [] } = useWorkItems();   // ✅ default []
  const { costs = [] } = useCosts();           // (future-proof)
  const { automations = [] } = useAutomations();
  const { user } = useAuth();

  const [kpis, setKpis] = useState({
    p0p1: 0,
    slaBreaches: 0,
    mttr: 0,
    openRequests: 0,
  });
  const [streamed, setStreamed] = useState([]);

  // ✅ Calculate KPIs safely
  useEffect(() => {
    if (!Array.isArray(workItems) || workItems.length === 0) return;

    const myItems = workItems.filter((w) => w && w.assignedTo === user?.id);
    const teamItems = workItems.filter((w) => w && w.teamId === user?.teamId);

    let calc = { p0p1: 0, slaBreaches: 0, mttr: 0, openRequests: 0 };

    const relevant =
      role === "manager" ? teamItems : role === "engineer" ? myItems : workItems;

    calc.p0p1 = relevant.filter((w) => w && (w.priority === "P0" || w.priority === "P1")).length;
    calc.slaBreaches = relevant.filter((w) => w && w.slaBreached).length;
    calc.openRequests = relevant.filter((w) => w && w.type === "request" && w.status !== "closed").length;

    const resolved = relevant.filter((w) => w && w.status === "resolved" && w.closedAt && w.createdAt);
    if (resolved.length) {
      calc.mttr =
        resolved.reduce((sum, w) => sum + (w.closedAt - w.createdAt), 0) /
        resolved.length /
        3600000; // hrs
    }

    setKpis(calc);
  }, [role, workItems, user]);

  // ✅ Stream insights (safe)
  useEffect(() => {
    let idx = 0;
    const insights = [
      { id: "svc1", text: "Service A showing higher latency", type: "health" },
      { id: "auto1", text: "2 pending automations could save 200 hrs", type: "automation" },
      { id: "cost1", text: "Team spend increased 15% this month", type: "cost" },
    ];

    const interval = setInterval(() => {
      if (idx < insights.length) {
        setStreamed((prev) => [...prev, insights[idx]]);
        idx++;
      } else {
        clearInterval(interval);
      }
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-4 flex flex-col gap-6">
      <h2 className="text-xl font-semibold">Pulse Dashboard</h2>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Link to="/queue" className="p-4 border rounded-lg bg-white shadow hover:shadow-md flex flex-col gap-1">
          <div className="flex items-center gap-2 text-red-600">
            <AlertTriangle size={18} /> P0/P1 Active
          </div>
          <span className="text-2xl font-bold">{kpis.p0p1}</span>
        </Link>

        <Link to="/queue" className="p-4 border rounded-lg bg-white shadow hover:shadow-md flex flex-col gap-1">
          <div className="flex items-center gap-2 text-yellow-600">
            <Clock size={18} /> SLA Breaches
          </div>
          <span className="text-2xl font-bold">{kpis.slaBreaches}</span>
        </Link>

        <div className="p-4 border rounded-lg bg-white shadow flex flex-col gap-1">
          <div className="flex items-center gap-2 text-blue-600">
            <TrendingDown size={18} /> MTTR (hrs)
          </div>
          <span className="text-2xl font-bold">
            {kpis.mttr ? kpis.mttr.toFixed(1) : "—"}
          </span>
        </div>

        <Link to="/queue" className="p-4 border rounded-lg bg-white shadow hover:shadow-md flex flex-col gap-1">
          <div className="flex items-center gap-2 text-green-600">
            <Activity size={18} /> Open Requests
          </div>
          <span className="text-2xl font-bold">{kpis.openRequests}</span>
        </Link>
      </div>

      {/* Secondary Insights */}
      <div className="p-3 border rounded-lg bg-white shadow flex flex-col gap-2">
        <h3 className="font-semibold mb-1">Insights</h3>
        {streamed.length === 0 && (
          <p className="text-sm text-gray-500">Loading insights…</p>
        )}
        {Array.isArray(streamed) &&
          streamed.filter(Boolean).map((s) => (
            <div key={s.id} className="text-sm border-b last:border-none pb-1 text-gray-700">
              {s.type === "health" && (
                <Link to="/queue" className="text-blue-600 hover:underline">
                  {s.text}
                </Link>
              )}
              {s.type === "automation" && (
                <Link to="/intelligence" className="text-purple-600 hover:underline">
                  {s.text}
                </Link>
              )}
              {s.type === "cost" && (
                <Link to="/pulse" className="text-orange-600 hover:underline">
                  {s.text}
                </Link>
              )}
            </div>
          ))}
      </div>
    </div>
  );
}