// src/db/dbClient.ts
import { openDB, IDBPDatabase } from "idb";
import type { AIOpsDB } from "./seedIndexedDB";
import { enqueue } from "./syncQueue";
import { generateImmutableHash } from "../utils/auditUtils";

// ---------------------------------
// DB cache per tenant
// ---------------------------------
const dbCache: Record<string, Promise<IDBPDatabase<AIOpsDB>>> = {};

export const getDB = async (tenantId: string) => {
  if (!dbCache[tenantId]) {
    const { initDB } = await import("./seedIndexedDB");
    dbCache[tenantId] = initDB(tenantId);
  }
  return dbCache[tenantId];
};

// ---------------------------------
// Activity Event
// ---------------------------------
export interface ActivityEvent {
  id: string;
  timestamp: string;
  tenantId: string;
  message: string;
  storeName: string;
  recordId: string;
  action: "create" | "update" | "delete";
}

// ---------------------------------
// Watchers (observability)
// ---------------------------------
type WatchCallback<T> = (entity: T) => void;
const watchers: Record<string, WatchCallback<any>[]> = {};

export const watch = <T>(
  storeName: keyof AIOpsDB,
  callback: WatchCallback<T>
) => {
  const key = storeName.toString();
  if (!watchers[key]) {
    watchers[key] = [];
  }
  watchers[key].push(callback as any);
  return () => {
    watchers[key] = watchers[key].filter((cb) => cb !== callback);
  };
};

const notifyWatchers = (storeName: keyof AIOpsDB, entity: any) => {
  const key = storeName.toString();
  if (watchers[key]) {
    watchers[key].forEach((cb) => cb(entity));
  }
};

// ---------------------------------
// Internal: Activity Timeline
// ---------------------------------
const logActivityEvent = async (
  tenantId: string,
  event: ActivityEvent
) => {
  const db = await getDB(tenantId);
  await db.add("activity_timeline", event);
};

// ---------------------------------
// Internal: Audit Logging
// ---------------------------------
const logAuditEvent = async (
  tenantId: string,
  storeName: keyof AIOpsDB,
  entityId: string,
  action: string,
  userId?: string,
  description?: string,
  tags?: string[]
) => {
  const timestamp = new Date().toISOString();
  const auditLog = {
    id: crypto.randomUUID(),
    entity_type: storeName,
    entity_id: entityId,
    action,
    description: description || `${storeName} ${action}`,
    timestamp,
    user_id: userId || null,
    tags: tags || [],
    hash: await generateImmutableHash({
      entity_type: storeName,
      entity_id: entityId,
      action,
      timestamp,
    }),
  };
  const db = await getDB(tenantId);
  await db.add("audit_logs", auditLog);
};

// ---------------------------------
// CRUD with Audit + Activity + Sync
// ---------------------------------
interface AuditMetadata {
  action?: string;
  description?: string;
  tags?: string[];
}

export const putWithAudit = async <T>(
  tenantId: string,
  storeName: keyof AIOpsDB,
  entity: T & { id: string },
  userId?: string,
  auditMetadata?: AuditMetadata
) => {
  const db = await getDB(tenantId);
  const timestamp = new Date().toISOString();

  // Save entity
  await db.put(storeName, entity);

  // Log audit
  await logAuditEvent(
    tenantId,
    storeName,
    entity.id,
    auditMetadata?.action || "update",
    userId,
    auditMetadata?.description,
    auditMetadata?.tags
  );

  // Log activity
  await logActivityEvent(tenantId, {
    id: crypto.randomUUID(),
    tenantId,
    timestamp,
    message:
      auditMetadata?.description ||
      `Entity in ${storeName} updated (${entity.id})`,
    storeName: storeName.toString(),
    recordId: entity.id,
    action: (auditMetadata?.action as any) || "update",
  });

  // Enqueue for sync
  await enqueue(tenantId, {
    id: crypto.randomUUID(),
    storeName: storeName.toString(),
    entityId: entity.id,
    action: auditMetadata?.action || "update",
    payload: entity,
    timestamp,
  });

  // Notify watchers
  notifyWatchers(storeName, entity);

  return entity;
};

export const removeWithAudit = async (
  tenantId: string,
  storeName: keyof AIOpsDB,
  entityId: string,
  userId?: string,
  auditMetadata?: AuditMetadata
) => {
  const db = await getDB(tenantId);
  const timestamp = new Date().toISOString();

  // Delete entity
  await db.delete(storeName, entityId);

  // Log audit
  await logAuditEvent(
    tenantId,
    storeName,
    entityId,
    auditMetadata?.action || "delete",
    userId,
    auditMetadata?.description,
    auditMetadata?.tags
  );

  // Log activity
  await logActivityEvent(tenantId, {
    id: crypto.randomUUID(),
    tenantId,
    timestamp,
    message:
      auditMetadata?.description ||
      `Entity in ${storeName} deleted (${entityId})`,
    storeName: storeName.toString(),
    recordId: entityId,
    action: "delete",
  });

  // Enqueue for sync
  await enqueue(tenantId, {
    id: crypto.randomUUID(),
    storeName: storeName.toString(),
    entityId,
    action: auditMetadata?.action || "delete",
    payload: null,
    timestamp,
  });

  // Notify watchers
  notifyWatchers(storeName, { id: entityId, deleted: true });
};

// ---------------------------------
// Generic CRUD Helpers
// ---------------------------------
export const getById = async <T>(
  tenantId: string,
  storeName: keyof AIOpsDB,
  id: string
): Promise<T | undefined> => {
  const db = await getDB(tenantId);
  return db.get(storeName, id);
};

export const getAll = async <T>(
  tenantId: string,
  storeName: keyof AIOpsDB
): Promise<T[]> => {
  const db = await getDB(tenantId);
  return db.getAll(storeName);
};

// ---------------------------------
// Reset + Reseed Helpers
// ---------------------------------
export const resetDB = async (tenantId: string) => {
  const db = await getDB(tenantId);
  for (const store of db.objectStoreNames) {
    const tx = db.transaction(store, "readwrite");
    await tx.store.clear();
    await tx.done;
  }
};

export const reseedDB = async (tenantId: string) => {
  const { seedIndexedDB } = await import("./seedIndexedDB");
  await seedIndexedDB(tenantId);
};