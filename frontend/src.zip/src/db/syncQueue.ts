// src/db/syncQueue.ts
import { getDB } from "./dbClient";
import { AIOpsDB } from "./seedIndexedDB";
import { SyncItem } from "../sync/syncTypes";

const STORE = "sync_queue";

// ---------------------------------
// Queue Operations
// ---------------------------------
export const enqueue = async <T>(
  tenantId: string,
  item: Omit<SyncItem<T>, "status" | "enqueuedAt" | "metadata">
): Promise<void> => {
  const db = await getDB(tenantId);
  const syncItem: SyncItem<T> = {
    ...item,
    status: "pending",
    enqueuedAt: new Date().toISOString(),
    metadata: { attemptCount: 0 },
  };
  await db.put(STORE, syncItem);
};

export const getNextBatch = async <T>(
  tenantId: string,
  limit = 10
): Promise<SyncItem<T>[]> => {
  const db = await getDB(tenantId);
  const all = await db.getAll(STORE);
  return all
    .filter((i: SyncItem<T>) => i.status === "pending")
    .slice(0, limit);
};

export const markInProgress = async (tenantId: string, id: string) => {
  const db = await getDB(tenantId);
  const item = await db.get(STORE, id);
  if (item) {
    item.status = "in_progress";
    item.metadata.attemptCount += 1;
    item.metadata.lastAttemptAt = new Date().toISOString();
    await db.put(STORE, item);
  }
};

export const markSuccess = async (tenantId: string, id: string) => {
  const db = await getDB(tenantId);
  const item = await db.get(STORE, id);
  if (item) {
    item.status = "success";
    await db.put(STORE, item);
  }
};

export const markFailed = async (
  tenantId: string,
  id: string,
  error: string
) => {
  const db = await getDB(tenantId);
  const item = await db.get(STORE, id);
  if (item) {
    item.status = "failed";
    item.metadata.errorMessage = error;
    await db.put(STORE, item);
  }
};

export const markConflict = async (
  tenantId: string,
  id: string,
  details: any
) => {
  const db = await getDB(tenantId);
  const item = await db.get(STORE, id);
  if (item) {
    item.status = "conflict";
    item.metadata.conflictDetails = details;
    await db.put(STORE, item);
  }
};

export const clearQueue = async (tenantId: string) => {
  const db = await getDB(tenantId);
  await db.clear(STORE);
};

export const getAllQueueItems = async (tenantId: string) => {
  const db = await getDB(tenantId);
  return db.getAll(STORE);
};