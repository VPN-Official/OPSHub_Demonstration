import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";
import { openDB, IDBPDatabase } from "idb";
import type { AIOpsDB } from "../db/seedIndexedDB";
import { seedIndexedDB } from "../db/seedIndexedDB";

interface TenantContextType {
  tenantId: string | null;
  setTenant: (tenantId: string) => Promise<void>;
  db: IDBPDatabase<AIOpsDB> | null;
}

const TenantContext = createContext<TenantContextType | undefined>(undefined);

// ---------------------------------
// Provider
// ---------------------------------
export const TenantProvider = ({ children }: { children: ReactNode }) => {
  const [tenantId, setTenantId] = useState<string | null>(
    localStorage.getItem("tenantId")
  );
  const [db, setDb] = useState<IDBPDatabase<AIOpsDB> | null>(null);

  // Open DB when tenant changes
  useEffect(() => {
    if (!tenantId) return;

    const openTenantDB = async () => {
      const dbName = `aiops_tenant_${tenantId}`;
      const database = await openDB<AIOpsDB>(dbName, 1, {
        upgrade(db) {
          // create stores if missing (re-use schema from seedIndexedDB.ts)
          const stores = Object.keys(db.objectStoreNames);
          // if store doesn’t exist, seedIndexedDB will handle it
        },
      });
      setDb(database);

      // Seed IndexedDB for this tenant (only if fresh)
      await seedIndexedDB(database, tenantId);
    };

    openTenantDB();
  }, [tenantId]);

  // Switch tenant
  const setTenant = async (newTenantId: string) => {
    localStorage.setItem("tenantId", newTenantId);
    setTenantId(newTenantId);
    // db will refresh via useEffect
  };

  return (
    <TenantContext.Provider value={{ tenantId, setTenant, db }}>
      {children}
    </TenantContext.Provider>
  );
};

// ---------------------------------
// Hook
// ---------------------------------
export const useTenant = () => {
  const ctx = useContext(TenantContext);
  if (!ctx) throw new Error("useTenant must be used within TenantProvider");
  return ctx;
};