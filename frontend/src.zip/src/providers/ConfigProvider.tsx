import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from "react";
import { getById } from "../db/dbClient";
import type { AIOpsDB } from "../db/seedIndexedDB";

// ---------------------------------
// 1. Types
// ---------------------------------
interface ConfigContextType {
  statuses: Record<string, string[]> | null;
  priorities: Record<
    string,
    { label: string; color: string; sla_minutes: number }
  > | null;
  slas: Record<string, any> | null;
  kpis: any[] | null;

  refreshConfig: () => Promise<void>;
}

const ConfigContext = createContext<ConfigContextType | undefined>(undefined);

// ---------------------------------
// 2. Provider
// ---------------------------------
export const ConfigProvider = ({ children }: { children: ReactNode }) => {
  const [statuses, setStatuses] = useState<ConfigContextType["statuses"]>(null);
  const [priorities, setPriorities] =
    useState<ConfigContextType["priorities"]>(null);
  const [slas, setSlas] = useState<ConfigContextType["slas"]>(null);
  const [kpis, setKpis] = useState<ConfigContextType["kpis"]>(null);

  const refreshConfig = async () => {
    try {
      const s = await getById<any>("config_statuses", "global");
      const p = await getById<any>("config_priorities", "global");
      const sla = await getById<any>("config_slas", "global");
      const k = await getById<any>("config_kpis", "global");

      setStatuses(s || null);
      setPriorities(p || null);
      setSlas(sla || null);
      setKpis(k?.list || null);
    } catch (err) {
      console.error("❌ Failed to load config from IndexedDB", err);
    }
  };

  useEffect(() => {
    refreshConfig();
  }, []);

  return (
    <ConfigContext.Provider
      value={{
        statuses,
        priorities,
        slas,
        kpis,
        refreshConfig,
      }}
    >
      {children}
    </ConfigContext.Provider>
  );
};

// ---------------------------------
// 3. Hooks
// ---------------------------------
export const useConfig = () => {
  const ctx = useContext(ConfigContext);
  if (!ctx) throw new Error("useConfig must be used within ConfigProvider");
  return ctx;
};

export const useStatuses = () => {
  return useConfig().statuses;
};

export const usePriorities = () => {
  return useConfig().priorities;
};

export const useSLAs = () => {
  return useConfig().slas;
};

export const useKPIs = () => {
  return useConfig().kpis;
};