import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";

export type NotificationType =
  | "alert"
  | "sla_breach"
  | "sync_failure"
  | "ai_nudge"
  | "system"
  | "other";

export interface Notification {
  id: string;
  type: NotificationType;
  message: string;
  created_at: string; // ISO datetime
  status: "active" | "dismissed";
  ttl_hours: number; // time-to-live
}

interface NotificationContextType {
  notifications: Notification[];
  addNotification: (n: Omit<Notification, "id" | "created_at" | "status">) => void;
  dismissNotification: (id: string) => void;
  dismissAll: () => void;
  refreshNotifications: () => void;
  activeCount: number;
}

const NotificationContext = createContext<
  NotificationContextType | undefined
>(undefined);

// ---------------------------------
// Provider
// ---------------------------------

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Load from localStorage
  useEffect(() => {
    const raw = localStorage.getItem("notifications");
    if (raw) {
      const parsed: Notification[] = JSON.parse(raw);
      setNotifications(filterExpired(parsed));
    }
  }, []);

  // Persist to localStorage whenever notifications change
  useEffect(() => {
    localStorage.setItem("notifications", JSON.stringify(notifications));
  }, [notifications]);

  const addNotification: NotificationContextType["addNotification"] = (n) => {
    const notif: Notification = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      type: n.type,
      message: n.message,
      ttl_hours: n.ttl_hours || 48,
      created_at: new Date().toISOString(),
      status: "active",
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const dismissNotification = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, status: "dismissed" } : n))
    );
  };

  const dismissAll = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, status: "dismissed" })));
  };

  const refreshNotifications = () => {
    setNotifications((prev) => filterExpired(prev));
  };

  const filterExpired = (notifs: Notification[]) => {
    const now = new Date();
    return notifs.filter((n) => {
      const expiry = new Date(n.created_at);
      expiry.setHours(expiry.getHours() + n.ttl_hours);
      return expiry > now;
    });
  };

  const activeCount = notifications.filter((n) => n.status === "active").length;

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        addNotification,
        dismissNotification,
        dismissAll,
        refreshNotifications,
        activeCount,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

// ---------------------------------
// Hook
// ---------------------------------

export const useNotifications = () => {
  const ctx = useContext(NotificationContext);
  if (!ctx) throw new Error("useNotifications must be used within NotificationProvider");
  return ctx;
};