import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
  useCallback,
} from "react";
import { getAll, bulkPut, remove } from "../db/dbClient";
import { AIOpsDB } from "../db/seedIndexedDB";

interface SyncStatus {
  store: keyof AIOpsDB;
  lastSynced: string | null;
  pending: number;
  status: "idle" | "syncing" | "error";
  error?: string | null;
}

interface SyncContextType {
  syncStatuses: Record<keyof AIOpsDB, SyncStatus>;
  forceSync: (store: keyof AIOpsDB) => Promise<void>;
  reseedAndSync: () => Promise<void>;
}

const SyncContext = createContext<SyncContextType | undefined>(undefined);

// Utility: simulate backend call
const pushToBackend = async (store: string, payload: any[]) => {
  console.log(`📤 Syncing ${payload.length} items from ${store} to backend...`);
  await new Promise((res) => setTimeout(res, 300)); // simulate latency
  // TODO: Replace with real fetch → API Gateway / Kafka producer
  return { success: true };
};

// Provider
export const SyncProvider = ({ children }: { children: ReactNode }) => {
  const [syncStatuses, setSyncStatuses] = useState<
    Record<keyof AIOpsDB, SyncStatus>
  >({} as any);

  // Initialize sync statuses for each store
  useEffect(() => {
    const stores: (keyof AIOpsDB)[] = [
      "incidents",
      "problems",
      "change_requests",
      "service_requests",
      "maintenances",
      "alerts",
      "metrics",
      "logs",
      "events",
      "traces",
      "value_streams",
      "business_services",
      "service_components",
      "assets",
      "customers",
      "vendors",
      "contracts",
      "cost_centers",
      "risks",
      "compliance",
      "kpis",
      "knowledge_base",
      "runbooks",
      "automation_rules",
      "ai_agents",
      "audit_logs",
      "activities",
    ];

    const initial: any = {};
    for (const store of stores) {
      initial[store] = {
        store,
        lastSynced: null,
        pending: 0,
        status: "idle",
      };
    }
    setSyncStatuses(initial);
  }, []);

  // Core sync function
  const forceSync = useCallback(
    async (store: keyof AIOpsDB) => {
      try {
        setSyncStatuses((prev) => ({
          ...prev,
          [store]: { ...prev[store], status: "syncing", error: null },
        }));

        const items = await getAll<any>(store);
        const dirtyItems = items.filter((x) => x.sync_status !== "clean");

        if (dirtyItems.length === 0) {
          setSyncStatuses((prev) => ({
            ...prev,
            [store]: {
              ...prev[store],
              status: "idle",
              pending: 0,
              lastSynced: new Date().toISOString(),
            },
          }));
          return;
        }

        const resp = await pushToBackend(store, dirtyItems);

        if (resp.success) {
          // Mark all synced
          const clean = dirtyItems.map((x) => ({
            ...x,
            sync_status: "clean",
            synced_at: new Date().toISOString(),
          }));
          await bulkPut(store, clean);

          setSyncStatuses((prev) => ({
            ...prev,
            [store]: {
              ...prev[store],
              status: "idle",
              pending: 0,
              lastSynced: new Date().toISOString(),
            },
          }));
        } else {
          throw new Error("Backend rejected sync");
        }
      } catch (err: any) {
        console.error(`❌ Sync failed for ${store}`, err);
        setSyncStatuses((prev) => ({
          ...prev,
          [store]: {
            ...prev[store],
            status: "error",
            error: err.message,
          },
        }));
      }
    },
    []
  );

  // Auto-sync on reconnect
  useEffect(() => {
    const handleOnline = () => {
      console.log("🌐 Online — flushing sync queues");
      Object.keys(syncStatuses).forEach((store) =>
        forceSync(store as keyof AIOpsDB)
      );
    };
    window.addEventListener("online", handleOnline);
    return () => window.removeEventListener("online", handleOnline);
  }, [syncStatuses, forceSync]);

  // Reseed + sync helper
  const reseedAndSync = useCallback(async () => {
    const { reseedDB } = await import("../db/seedIndexedDB");
    await reseedDB();
    for (const store of Object.keys(syncStatuses)) {
      await forceSync(store as keyof AIOpsDB);
    }
  }, [syncStatuses, forceSync]);

  return (
    <SyncContext.Provider value={{ syncStatuses, forceSync, reseedAndSync }}>
      {children}
    </SyncContext.Provider>
  );
};

// Hook
export const useSync = () => {
  const ctx = useContext(SyncContext);
  if (!ctx) throw new Error("useSync must be used within SyncProvider");
  return ctx;
};