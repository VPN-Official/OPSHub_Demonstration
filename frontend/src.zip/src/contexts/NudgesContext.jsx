import React, { createContext, useContext, useState, useEffect } from "react";
import { getAll, setItem, delItem, clearStore, seedAll } from "../utils/db.js";

const NudgesContext = createContext();

export function NudgesProvider({ children }) {
  const [nudges, setNudges] = useState([]);

  async function load() {
    const items = await getAll("nudges");
    if (!items.length) {
      await seedAll({ nudges: [] });
    }
    setNudges(items);
  }

  async function addNudge(nudge) {
    await setItem("nudges", nudge);
    load();
  }

  async function removeNudge(id) {
    await delItem("nudges", id);
    load();
  }

  async function clearAll() {
    await clearStore("nudges");
    load();
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <NudgesContext.Provider value={{ nudges, addNudge, removeNudge, clearAll }}>
      {children}
    </NudgesContext.Provider>
  );
}

export function useNudges() {
  return useContext(NudgesContext);
}