import React, { createContext, useContext, useState, useEffect } from "react";
import { getAll, setItem, delItem, clearStore, seedAll } from "../utils/db.js";

const ScheduleContext = createContext();

export function ScheduleProvider({ children }) {
  const [schedule, setSchedule] = useState([]);

  async function load() {
    const items = await getAll("schedule");
    if (!items.length) {
      await seedAll({ schedule: [] });
    }
    setSchedule(items);
  }

  async function addEvent(event) {
    await setItem("schedule", event);
    load();
  }

  async function removeEvent(id) {
    await delItem("schedule", id);
    load();
  }

  async function clearAll() {
    await clearStore("schedule");
    load();
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <ScheduleContext.Provider
      value={{ schedule, addEvent, removeEvent, clearAll }}
    >
      {children}
    </ScheduleContext.Provider>
  );
}

export function useSchedule() {
  return useContext(ScheduleContext);
}