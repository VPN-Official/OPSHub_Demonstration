import React, { createContext, useContext, useState, useEffect } from "react";
import { getAll, setItem, delItem, clearStore, seedAll } from "../utils/db.js";

const WorkItemsContext = createContext();

export function WorkItemsProvider({ children }) {
  const [workItems, setWorkItems] = useState([]);

  async function load() {
    const items = await getAll("workItems");
    if (!items.length) {
      await seedAll({ workItems: [] }); // ✅ centralized seeding
    }
    setWorkItems(items);
  }

  async function addWorkItem(item) {
    await setItem("workItems", item);
    load();
  }

  async function removeWorkItem(id) {
    await delItem("workItems", id);
    load();
  }

  async function clearAll() {
    await clearStore("workItems");
    load();
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <WorkItemsContext.Provider
      value={{ workItems, addWorkItem, removeWorkItem, clearAll }}
    >
      {children}
    </WorkItemsContext.Provider>
  );
}

export function useWorkItems() {
  return useContext(WorkItemsContext);
}