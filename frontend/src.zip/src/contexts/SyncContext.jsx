import React, { createContext, useContext, useState, useEffect } from "react";
import { getAll, setItem, delItem, clearStore, seedAll } from "../utils/db.js";
import { useToast } from "./ToastContext.jsx"; // ✅ for sync notifications

const SyncContext = createContext();

export function SyncProvider({ children }) {
  const [syncQueue, setSyncQueue] = useState([]);
  const { addToast } = useToast();

  // 🔄 Load queue from IndexedDB
  async function load() {
    const items = await getAll("syncQueue");
    if (!items.length) {
      await seedAll({ syncQueue: [] }); // ✅ centralized seeding
    }
    setSyncQueue(items);
  }

  // ➕ Add item to sync queue
  async function enqueue(item) {
    await setItem("syncQueue", item);
    addToast("Item queued for sync", "info");
    load();
  }

  // ❌ Remove item from sync queue
  async function dequeue(id) {
    await delItem("syncQueue", id);
    addToast("Item removed from sync queue", "success");
    load();
  }

  // 🧹 Clear queue
  async function clearAll() {
    await clearStore("syncQueue");
    addToast("Sync queue cleared", "info");
    load();
  }

  // 🔁 On mount, load queue
  useEffect(() => {
    load();
  }, []);

  // 🌐 Attempt to sync when online
  useEffect(() => {
    async function handleOnline() {
      if (syncQueue.length > 0) {
        try {
          // ✅ Replace with your actual sync logic (API calls etc.)
          console.log("🔄 Syncing items:", syncQueue);

          // Clear queue after sync success
          await clearStore("syncQueue");
          setSyncQueue([]);
          addToast("All queued items synced successfully", "success");
        } catch (err) {
          console.error("❌ Sync failed:", err);
          addToast("Sync failed, will retry later", "error");
        }
      }
    }

    window.addEventListener("online", handleOnline);
    return () => window.removeEventListener("online", handleOnline);
  }, [syncQueue]);

  return (
    <SyncContext.Provider value={{ syncQueue, enqueue, dequeue, clearAll }}>
      {children}
    </SyncContext.Provider>
  );
}

export function useSync() {
  return useContext(SyncContext);
}