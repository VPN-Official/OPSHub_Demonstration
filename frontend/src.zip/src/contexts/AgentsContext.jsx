import React, { createContext, useContext, useState, useEffect } from "react";
import { getAll, setItem, delItem, clearStore, seedAll } from "../utils/db.js";

const AgentsContext = createContext();

export function AgentsProvider({ children }) {
  const [agents, setAgents] = useState([]);

  async function load() {
    const items = await getAll("agents");
    if (!items.length) {
      await seedAll({ agents: [] });
    }
    setAgents(items);
  }

  async function addAgent(agent) {
    await setItem("agents", agent);
    load();
  }

  async function removeAgent(id) {
    await delItem("agents", id);
    load();
  }

  async function clearAll() {
    await clearStore("agents");
    load();
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <AgentsContext.Provider value={{ agents, addAgent, removeAgent, clearAll }}>
      {children}
    </AgentsContext.Provider>
  );
}

export function useAgents() {
  return useContext(AgentsContext);
}